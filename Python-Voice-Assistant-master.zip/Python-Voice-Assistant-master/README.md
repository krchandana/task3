# Python-Voice-Assistant

Pyaudio can be installed from .whl file

Collect all the API key from their respective website.
